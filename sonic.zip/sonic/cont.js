var Cont = {
	preload: function(){
		game.load.image('back', 'back.png')
	},
	create: function(){

		this.btn = game.add.sprite(382.5, 400, 'back')
        this.btn.scale.setTo(0.5)
		this.scoreText = game.add.text(150, 100, 'Wait for the continue!' , { fontSize: '50px', fill: '#6ecc10' });
		this.btn.inputEnabled=true;
        this.btn.events.onInputDown.add(this.menu);
	}, 
	update: function(){

	},
	menu: function(){
		game.state.start('menu')
	}
}