var Menu = { 
	btn: null, 
	bg: null,
	n: null,
    audio: null, 
	preload: function(){
		game.load.image('bg', 'menubg.gif')
		game.load.image('btn', 'btnmenu.png')
		game.load.image('start', 'start.jpg')
		game.load.image('bg1','1.png')
		game.load.image('bg2','2.png')
		game.load.image('bg3','3.png')
		game.load.image('bg4','4.png')
		game.load.image('bg5','5.png')
		game.load.image('bg6','6.png')
		game.load.image('bg7','7.png')
		game.load.image('bg8','8.png')
		game.load.image('bg9','9.png')
		game.load.image('bg10','10.png')
		game.load.image('bg11','11.png')
		game.load.image('bg12','12.png')
		game.load.image('bg13','13.png')
		game.load.image('bg14','14.png')
		game.load.image('bg15','15.png')
		game.load.image('bg16','16.png')
		game.load.image('bg17','17.png')
		game.load.image('bg18','18.png')
		game.load.image('bg19','19.png')
		game.load.image('bg20','20.png')
		game.load.image('bg21','21.png')
		game.load.image('bg22','22.png')
		game.load.image('bg23','23.png')
		game.load.image('bg24','24.png')
		game.load.image('bg25','25.png')
        game.load.audio('audio','menu.mp3')

	},
	create: function(){
        this.n = 1
        this.audio = game.add.audio('audio', 0.5, true)
        this.audio.play()
        
		game.time.events.loop(Phaser.Timer.SECOND/7, this.updateCounter, this);

	},
	update: function(){
		
	},
	start: function(){
        
		game.state.start('start')	
	},
	updateCounter: function(){
		if(Menu.n==26){
			Menu.n=1
		}
		var bg = game.add.sprite(0, 0, 'bg'+Menu.n)
		Menu.n +=1
		bg.width=1000
		bg.height=600
		this.btn = game.add.sprite(390, 400, 'btn')
		this.btn.scale.setTo(0.1212121)
		this.btn.inputEnabled=true;
        this.btn.events.onInputDown.add(this.start);
	}

}