var Lost = {
    audio: null, 
	preload: function(){
		game.load.spritesheet('sonic', 'sonic.png',49.2222, 49, 63)
		game.load.image('back', 'back.png')
        game.load.audio('audio', 'S1_A3.wav')
	},
	create: function(){
        this.audio = game.add.audio('audio', 1)
        this.audio.play()
        MainGame.audio.pause()   
		this.btn = game.add.sprite(382.5, 400, 'back')
        this.btn.scale.setTo(0.5)
       	this.sonic = game.add.sprite(500, 300, 'sonic');
       	this.sonic.scale.setTo(3)
       	this.sonic.anchor.setTo(0.5,0.5);
        game.physics.arcade.enable(this.sonic);
        this.sonic.animations.add('lost', [57, 58, 59, 60, 61], 3, true);
        this.sonic.animations.play('lost')
		this.scoreText = game.add.text(100, 100, 'Bad!' , { fontSize: '50px', fill: '#6ecc10' });
		this.btn.inputEnabled=true;
        this.btn.events.onInputDown.add(this.menu);
	}, 
	update: function(){

	},
	menu: function(){
		game.state.start('menu')
	}
}