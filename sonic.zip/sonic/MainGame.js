var MainGame = {
	bg: null, 
	sonic: null, 
	ring: null, 
    platformsbg: null, 
	platforms: null, 
	rings: null, 
	up: null, 
	left: null, 
	right: null, 
	down: null,
	scoreText: null, 
	score: null, 
    timeText: null, 
    ringsText: null,
    ringColl: null,
    timeI: null,
    timeU: null,
    n: null, 
    n1: null, 
    groundbg: null,
    ground: null,
    trees: null, 
    tree: null, 
    totem: null, 
    totems: null, 
    flower: null, 
    fish: null, 
    bee: null, 
    bogKor: null, 
    hitPlatform: null, 
     hitPlatform2: null,
    hitPlatform1: null,
    heart: null,
    lostText: null, 
    tableEnd: null, 
    ringSound: null, 
    ringLos: null, 
    jumpSound: null, 
	preload: function(){
        game.load.audio('jumpSound', 'S1_A2.wav')
        game.load.audio('ringColl', 'rings.mp3')
        game.load.audio('ringLos', 'ringLos.mp3')
        game.load.audio('audio', 'game.mp3')
		game.load.image('bg', 'bg.png')
		game.load.image('ground', 'ground.png')
        game.load.image('ground2', 'ground2.png')
        game.load.image('ground3', 'ground3.png')
        game.load.image('ground4', 'ground4.png')
		game.load.spritesheet('ring', 'ring.png',64, 57)
		game.load.spritesheet('sonic', 'sonic.png',49.2222, 49, 63)
		game.load.image('strel', 'strel.png')
		game.load.image('up', 'Up.png')
        game.load.image('test', 'start_btn.png')
        game.load.spritesheet('fish', 'robot3.png', 38.5, 37)
        game.load.image('end', 'end.png')
        game.load.spritesheet('flower', 'flower.png', 30, 48)
        game.load.image('groundbg', 'groundbg.png')
        game.load.spritesheet('bogKor', 'robot1.png', 48.66667, 31)
        game.load.spritesheet('bee', 'robot2.png', 57, 30)
        game.load.image('tree', 'tree.png')
        game.load.image('platform', 'platform.png')
        game.load.image('totem', 'totem.png')
    },
	create: function(){
        
                //ALL 
        this.jumpSound = game.add.audio('jumpSound', 1);
        this.ringLos = game.add.audio('ringLos', 1);
        this.ringSound = game.add.audio('ringColl', 1);
        this.audio = game.add.audio('audio', 0.5, true)
        
        //play
        
        this.audio.play()
        
        //pause
        
        
        
                //All needed things
        
        this.score=0
        this.heart=3
        this.n=0
        this.n1=0
        this.timeU=0
        this.timeI=0
        this.ringColl=0
        
                //BACKGROUND OF WORLD
        
		game.physics.startSystem(Phaser.Physics.ARCADE);
		for(var i=0; i<20; i++){
			this.bg = game.add.sprite(this.n1, 0, 'bg')
			this.bg.scale.setTo(1.875)
			this.n1 = this.n1 + 963.75
		}

                //ALL DECORATIONS

        //all flowers of world

        this.flower = []

        for(var i = 0; i<4; i++){
            this.flower[i] = game.add.sprite(150+i*500, 730, 'flower');
            this.flower[i].animations.add('wait', [0, 1], 2, true);
            this.flower[i].animations.play('wait')
            this.flower[i].scale.setTo(2.5)
        }

        this.flower[4] = game.add.sprite(1200, 550, 'flower');
        this.flower[5] = game.add.sprite(3540, 720, 'flower');
        this.flower[6] = game.add.sprite(4100, 600, 'flower');
        this.flower[7] = game.add.sprite(5990, 240, 'flower');

        for(var i = 0; i<8; i++){
            this.flower[i].animations.add('wait', [0, 1], 2, true);
            this.flower[i].animations.play('wait')
            this.flower[i].scale.setTo(2.5)
        }

        //all totems of world

        this.totems = game.add.group()

        this.totem = []
        this.totem[0] = this.totems.create(1900, 600, 'totem');
        this.totem[1] = this.totems.create(1250, 550, 'totem');
        this.totem[2] = this.totems.create(4882, 380, 'totem');
        this.totem[3] = this.totems.create(5717, 380, 'totem');

        for(var i = 0; i<4; i++){
            this.totem[i].scale.setTo(2)
        }

        //all trees of world

        this.trees = game.add.group()

        this.tree = []

        for(var i = 0; i<7; i++){
            this.tree[i] = this.trees.create(30+i*250, 350+Math.round(Math.random()*100), 'tree');
        }

        this.tree[7] = this.trees.create(1900, 300, 'tree');
        
        for(var i = 8; i<11; i++){
            this.tree[i] = this.trees.create(2715+(i-8)*150, 300+Math.round(Math.random()*100), 'tree');
        }
        
        this.tree[11] = this.trees.create(3215, 470, 'tree');
        
        
        for(var i = 12; i<14; i++){
            this.tree[i] = this.trees.create(3690+(i-12)*150, 300+Math.round(Math.random()*100), 'tree');
        }
        
        this.tree[14] = this.trees.create(4240, 300+Math.round(Math.random()*100), 'tree');
        
        for(var i = 15; i<19; i++){
            this.tree[i] = this.trees.create(6090+(i-15)*150, 10+Math.round(Math.random()*30), 'tree');
        }
        
        for(var i = 0; i<19; i++){
            this.tree[i].scale.setTo(0.2836879433)
        }
        
        
        
        

                //PLATFORMS OF WORLD

        this.platformsbg = game.add.group()

        this.groundbg = []
        this.groundbg[0] = this.platformsbg.create(0, 260, 'ground');
        this.groundbg[0].scale.setTo(2)
        this.groundbg[1] = this.platformsbg.create(1051, 660, 'groundbg');
        this.groundbg[1].scale.setTo(2)
        this.groundbg[2] = this.platformsbg.create(4190, -80, 'ground2');
        this.groundbg[2].scale.setTo(2)
        this.groundbg[3] = this.platformsbg.create(8394, -545, 'ground3');
        this.groundbg[3].scale.setTo(2)
        this.groundbg[4] = this.platformsbg.create(8394, -52, 'ground4');
        this.groundbg[4].scale.setTo(2)

		this.platforms = game.add.group();
		this.platforms.enableBody = true;

        this.ground = []

        this.ground[0] = this.platforms.create(0, 890, 'test')
        this.ground[0].width=2102

        this.ground[1] = this.platforms.create(1700, 870, 'test')
        this.ground[2] = this.platforms.create(1750, 840, 'test')
        this.ground[3] = this.platforms.create(1800, 810, 'test')
        this.ground[4] = this.platforms.create(1850, 780, 'test')
        this.ground[5] = this.platforms.create(1900, 750, 'test')
        this.ground[5].width=230

        this.ground[6] = this.platforms.create(2500, 720, 'test')

        for(var i=0; i<12; i++){
            this.ground[i+7] = this.platforms.create(2000+i*40, 720, 'test')
            this.ground[i+7].width=40
            this.ground[i+7].height=40
        }

        this.ground[19] = this.platforms.create(2800, 750, 'test')
        this.ground[20] = this.platforms.create(3100, 750, 'test')
        this.ground[20].width=120
        this.ground[21] = this.platforms.create(3220, 775, 'test')
        this.ground[21].width=60
        this.ground[22] = this.platforms.create(3280, 800, 'test')
        this.ground[22].width=60
        this.ground[23] = this.platforms.create(3340, 825, 'test')
        this.ground[23].width=60
        this.ground[24] = this.platforms.create(3400, 840, 'test')
        this.ground[24].width=60
        this.ground[25] = this.platforms.create(3400, 860, 'test')
        this.ground[26] = this.platforms.create(3650, 845, 'test')
        this.ground[26].width=30
        this.ground[27] = this.platforms.create(3680, 825, 'test')
        this.ground[27].width=30
        this.ground[28] = this.platforms.create(3710, 790, 'test')
        this.ground[28].width=30
        this.ground[29] = this.platforms.create(3740, 745, 'test')
        this.ground[29].width=30
        this.ground[30] = this.platforms.create(3770, 735, 'test')
        this.ground[30].width=450
        this.ground[31] = this.platforms.create(-10, 0, 'test')
        this.ground[31].width=10
        this.ground[31].height=960

        this.ground[32] = this.platforms.create(1051, 660, 'platform')
        this.ground[32].scale.setTo(2)

        this.ground[33] = this.platforms.create(0, -300, 'test')
        this.ground[33].width=15000

        this.ground[34] = this.platforms.create(4250, 670, 'test')
        this.ground[34].width=120
        this.ground[35] = this.platforms.create(4390, 600, 'test')
        this.ground[35].width=240
        this.ground[36] = this.platforms.create(4630, 500, 'test')
        this.ground[36].width=480

        for(var i=0; i<12; i++){
            this.ground[i+37] = this.platforms.create(5110+i*40, 500, 'test')
            this.ground[i+37].width=40
            this.ground[i+37].height=40
        }

        this.ground[49] = this.platforms.create(5490, 500, 'test')
        this.ground[49].width=480

        this.ground[50] = this.platforms.create(6000, 360, 'test')
        this.ground[50].width=700
        this.ground[50].height=10
        this.ground[51] = this.platforms.create(6000, 360, 'test')
        this.ground[51].width=60
        this.ground[52] = this.platforms.create(6700, 330, 'test')
        this.ground[52].width=60
        this.ground[52].height=50
        this.ground[53] = this.platforms.create(6760, 300, 'test')
        this.ground[53].width=60
        this.ground[53].height=50
        this.ground[54] = this.platforms.create(6820, 270, 'test')
        this.ground[54].width=60
        this.ground[54].height=50
        this.ground[55] = this.platforms.create(6880, 240, 'test')
        this.ground[55].width=60
        this.ground[55].height=50
        this.ground[56] = this.platforms.create(6940, 210, 'test')
        this.ground[56].width=150
        this.ground[56].height=50
        this.ground[57] = this.platforms.create(6500, 740, 'test')
        this.ground[57].width=690
        this.ground[58] = this.platforms.create(7190, 770, 'test')
        this.ground[58].width=60
        this.ground[59] = this.platforms.create(7250, 800, 'test')
        this.ground[59].width=60
        this.ground[59] = this.platforms.create(7300, 830, 'test')
        this.ground[59].width=60
        this.ground[60] = this.platforms.create(7350, 860, 'test')
        this.ground[60].width=800
        this.ground[61] = this.platforms.create(8150, 830, 'test')
        this.ground[61].width=60
        this.ground[62] = this.platforms.create(8210, 800, 'test')
        this.ground[62].width=60
        this.ground[63] = this.platforms.create(8270, 770, 'test')
        this.ground[63].width=60
        this.ground[64] = this.platforms.create(8300, 740, 'test')
        this.ground[64].width=150
        this.ground[65] = this.platforms.create(8450, 770, 'test')
        this.ground[65].width=60
        this.ground[66] = this.platforms.create(8510, 800, 'test')
        this.ground[66].width=60
        this.ground[67] = this.platforms.create(8570, 830, 'test')
        this.ground[67].width=60
        this.ground[68] = this.platforms.create(8630, 860, 'test')
        this.ground[68].width=250
        this.ground[69] = this.platforms.create(8880, 845, 'test')
        this.ground[69].width=30
        this.ground[70] = this.platforms.create(8950, 825, 'test')
        this.ground[70].width=30
        this.ground[71] = this.platforms.create(8980, 790, 'test')
        this.ground[71].width=30
        this.ground[72] = this.platforms.create(9010, 735, 'test')
        this.ground[72].width=770
        this.ground[73] = this.platforms.create(9780, 850, 'test')
        this.ground[73].width=1700
        this.ground[74] = this.platforms.create(11480, 770, 'test')
        this.ground[74].width=200
        this.ground[75] = this.platforms.create(11680, 730, 'test')
        this.ground[75].width=740
        this.ground[76] = this.platforms.create(12420, 760, 'test')
        this.ground[76].width=60
        this.ground[77] = this.platforms.create(12480, 790, 'test')
        this.ground[77].width=60
        this.ground[78] = this.platforms.create(12550, 820, 'test')
        this.ground[78].width=60
        this.ground[79] = this.platforms.create(12610, 850, 'test')
        this.ground[79].width=60
        this.ground[80] = this.platforms.create(12670, 880, 'test')
        this.ground[80].width=2130

        

        for(var i=0; i<81; i++){
            this.ground[i].body.immovable=true
        }
        
            //the table of ending
        
        this.tableEnd = game.add.sprite(13430, -100, 'end')
        this.tableEnd.scale.setTo(0.5)
        game.physics.arcade.enable(this.tableEnd);

                //RINGS

		this.rings = game.add.group()
		this.rings.enableBody = true;
		for (var i=0; i<16; i++){
			this.ring = this.rings.create(i*100+120, 850, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
			this.ring.animations.play('ringAn');
			this.ring.scale.setTo(0.75);
            }

        for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*100+2100, 500, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

         for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*100+1000, 500, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*100+2000, 500, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<4; i++){
            this.ring = this.rings.create(i*100+3200, 500-i*30, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<2; i++){
            this.ring = this.rings.create(i*100+4450, 500, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<2; i++){
            this.ring = this.rings.create(i*100+4750, 300, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<2; i++){
            this.ring = this.rings.create(i*100+5800, 300, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*60+6690, 290-i*30, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<3; i++){
            this.ring = this.rings.create(i*60+8300, 600, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*60+9530, 600, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<6; i++){
            this.ring = this.rings.create(i*40+10500, 700, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*60+12460, 700+i*30, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<5; i++){
            this.ring = this.rings.create(i*60+12810, 820, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
        }

        for(var i=0; i<3; i++){
            this.ring = this.rings.create(13500, 730+i*50, 'ring');
            this.ring.animations.add('ringAn', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 10, true)
            this.ring.animations.play('ringAn');
            this.ring.scale.setTo(0.75);
            
        }
    

                //ENEMIES

        this.bee = []
        this.bogKor = []
        this.fish = []
        
        //fish
        
        for(var i=0; i<2; i++){
            this.fish[i] = game.add.sprite(2200+i*200, 1000+i*200, 'fish');
            this.fish[i].animations.add('fish', [0, 1], 10, true)
            this.fish[i].scale.setTo(2)
            this.fish[i].animations.play('fish')
            game.physics.arcade.enable(this.fish[i]);
        }

        for(var i=2; i<4; i++){
            this.fish[i] = game.add.sprite(4780+i*200, 800*(i-2)*200, 'fish');
            this.fish[i].animations.add('fish', [0, 1], 10, true)
            this.fish[i].scale.setTo(2)
            this.fish[i].animations.play('fish')
            game.physics.arcade.enable(this.fish[i]);
        }

        for(var i=0; i<1; i++){
            this.bee[i] = game.add.sprite(1890, 350, 'bee');
            this.bee[i].animations.add('bee', [0, 1, 2, 3], 10, true)
            this.bee[i].scale.setTo(2)
            this.bee[i].animations.play('bee')
            game.physics.arcade.enable(this.bee[i]);
        }

        for(var i=1; i<2; i++){
            this.bee[i] = game.add.sprite(6650, 100, 'bee');
            this.bee[i].animations.add('bee', [0, 1, 2, 3], 10, true)
            this.bee[i].scale.setTo(2)
            this.bee[i].animations.play('bee')
            game.physics.arcade.enable(this.bee[i]);
        }
        
        for(var i=2; i<3; i++){
            this.bee[i] = game.add.sprite(7524, 670, 'bee');
            this.bee[i].animations.add('bee', [0, 1, 2, 3], 10, true)
            this.bee[i].scale.setTo(2)
            this.bee[i].animations.play('bee')
            game.physics.arcade.enable(this.bee[i]);
        }

        for(var i=0; i<1; i++){
            this.bogKor[i] = game.add.sprite(1590, 800, 'bogKor');
            this.bogKor[i].animations.add('bogKor', [0, 1, 2, 3], 10, true)
            this.bogKor[i].scale.setTo(2)
            this.bogKor[i].animations.play('bogKor')
            game.physics.arcade.enable(this.bogKor[i]);
        }

        for(var i=1; i<3; i++){
            this.bogKor[i] = game.add.sprite(4050+i*200, 700-i*100, 'bogKor');
            this.bogKor[i].animations.add('bogKor', [0, 1, 2, 3], 10, true)
            this.bogKor[i].scale.setTo(2)
            this.bogKor[i].animations.play('bogKor')
            game.physics.arcade.enable(this.bogKor[i]);
            this.bogKor[i].body.gravity.y=400
        }

        for(var i=3; i<4; i++){
            this.bogKor[i] = game.add.sprite(10450, 600, 'bogKor');
            this.bogKor[i].animations.add('bogKor', [0, 1, 2, 3], 10, true)
            this.bogKor[i].scale.setTo(2)
            this.bogKor[i].animations.play('bogKor')
            game.physics.arcade.enable(this.bogKor[i]);
            this.bogKor[i].body.gravity.y=400
        }

                


                //PLAYER SONIC


       this.sonic = game.add.sprite(50, 700, 'sonic');
       this.sonic.scale.setTo(2)
       this.sonic.anchor.setTo(0.5,0.5);
        game.physics.arcade.enable(this.sonic);
        this.sonic.body.bounce.y = 0.2;
        this.sonic.body.gravity.y = 500;
        this.sonic.animations.add('wait', [0, 1, 2, 3, 2, 1], 2, true);
        this.sonic.animations.add('run', [4, 5, 6, 7, 8], 20, true);
        this.sonic.animations.add('runF', [16, 17, 18, 19], 20, true);
        this.sonic.animations.add('jump1', [28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 30, 31, 28, 29, 30, 31,], 20, true);
        this.sonic.animations.add('jump2', [32, 33, 34, 35, 32, 33, 34, 35, 32, 33, 34, 35, 32, 33, 34, 35], 20, true);
        this.sonic.animations.add('damage', [40, 41], 15, true);
        this.sonic.animations.add('lost', [57, 58, 59, 60, 61], 3, false);
        this.sonic.animations.play('wait')

                //KEYBOARD

        this.up = game.add.sprite(70, 360,  'up')
        this.up.scale.setTo(3)
        this.up.inputEnabled=true;
        this.up.events.onInputDown.add(this.jump);
        this.up.events.onInputUp.add(this.stop);
        this.up.fixedToCamera = true;

        this.left = game.add.sprite(40, 460,  'strel')
        this.left.scale.setTo(3)
        this.left.angle=270
        this.left.inputEnabled=true;
        this.left.events.onInputDown.add(this.runL);
        this.left.events.onInputUp.add(this.stop);
        this.left.fixedToCamera = true;

        this.right = game.add.sprite(160, 400,  'strel')
        this.right.scale.setTo(3)
        this.right.inputEnabled=true;
        this.right.angle=90
        this.right.events.onInputDown.add(this.runR);
        this.right.events.onInputUp.add(this.stop);
        this.right.fixedToCamera = true;

                //CAMERA

        game.world.setBounds(0, 0, 14500, 960)
    	game.camera.follow(this.sonic)

                //SCORE WHAT IN THE TOP and LEFT OF CAMERA

    	this.scoreText = game.add.text(16, 16, 'SCORE 0', { fontSize: '32px', fill: '#ffe500' });
        this.timeText = game.add.text(16, 64, 'TIME 0:0', { fontSize: '32px', fill: '#ffe500' });
        this.ringsText = game.add.text(16, 112, 'RINGS 0', { fontSize: '32px', fill: '#ffe500' });
        this.scoreText.fixedToCamera = true;
        this.ringsText.fixedToCamera = true;
        this.timeText.fixedToCamera = true;

        game.time.events.loop(Phaser.Timer.SECOND, this.timeChan, this);

	},
	update: function(){
		this.hitPlatform = game.physics.arcade.collide(this.sonic, this.platforms)
		game.physics.arcade.overlap(
            	//между кем идет соприкосновение
            	this.sonic, MainGame.rings, 
            	//что делать при вхождении
            	MainGame.collect, 
            	//откуда идет соприкосновение: сверху или снизу
            	null, this)
        for(var i =1; i<4; i++){
            this.hitPlatform2 = game.physics.arcade.collide(this.bogKor[i], this.platforms)
        }

        if(this.sonic.position.x > 13500 && this.sonic.position.x < 14000){
            game.state.start('win')
        }

        for(var i=0; i<4; i++){
            game.physics.arcade.overlap(
                    //между кем идет соприкосновение
                    this.sonic, this.fish[i], 
                    //что делать при вхождении
                    MainGame.damage, 
                    //откуда идет соприкосновение: сверху или снизу
                    null, this)
        }

        for(var i=0; i<4; i++){
            game.physics.arcade.overlap(
                    //между кем идет соприкосновение
                    this.sonic, this.bogKor[i], 
                    //что делать при вхождении
                    MainGame.damage, 
                    //откуда идет соприкосновение: сверху или снизу
                    null, this)
        }

        for(var i=0; i<3; i++){
            game.physics.arcade.overlap(
                    //между кем идет соприкосновение
                    this.sonic, this.bee[i], 
                    //что делать при вхождении
                    MainGame.damage, 
                    //откуда идет соприкосновение: сверху или снизу
                    null, this)
        }

            for(var i=0; i<2; i++){
                if(this.fish[i].position.y<1300){
                    this.fish[i].body.gravity.y=300
                }
                if(this.fish[i].position.y>800){
                    this.fish[i].body.gravity.y=-300
                }
            }

            for(var i=2; i<4; i++){
                if(this.fish[i].position.y<1000){
                    this.fish[i].body.gravity.y=300
                }
                if(this.fish[i].position.y>600){
                    this.fish[i].body.gravity.y=-300
                }
            }

            for(var i=0; i<1; i++){
                if(this.bogKor[i].position.x>1500){
                    this.bogKor[i].body.velocity.x=-200
                    this.bogKor[i].scale.x=2;
                }
                if(this.bogKor[i].position.x<500){
                    this.bogKor[i].body.velocity.x=200
                    this.bogKor[i].scale.x=-2;
                }
            }

            for(var i=1; i<2; i++){
                if(this.bogKor[i].position.x>=4050){
                    this.bogKor[i].body.velocity.x=-200
                    this.bogKor[i].scale.x=2;
                }
                if(this.bogKor[i].position.x<3950){
                    this.bogKor[i].body.velocity.x=200
                    this.bogKor[i].scale.x=-2;
                }
            }

            for(var i=3; i<4; i++){
                if(this.bogKor[i].position.x>=10400){
                    this.bogKor[i].body.velocity.x=-200
                    this.bogKor[i].scale.x=2;
                }
                if(this.bogKor[i].position.x<9900){
                    this.bogKor[i].body.velocity.x=200
                    this.bogKor[i].scale.x=-2;
                }
            }


            for(var i=0; i<1; i++){
                if(this.bee[i].position.x>1800){
                    this.bee[i].body.velocity.x=-300
                    this.bee[i].scale.x=2;
                }
                if(this.bee[i].position.x<1000){
                    this.bee[i].body.velocity.x=300
                    this.bee[i].scale.x=-2;
                }
            }

            for(var i=1; i<2; i++){
                if(this.bee[i].position.x>6640+(i-1)*200){
                    this.bee[i].body.velocity.x=-300
                    this.bee[i].scale.x=2;
                }
                if(this.bee[i].position.x<6100+(i-1)*200){
                    this.bee[i].body.velocity.x=300
                    this.bee[i].scale.x=-2;
                }
            }
        
            for(var i=2; i<3; i++){
                if(this.bee[i].position.x<7525){
                    this.bee[i].body.velocity.x=300
                    this.bee[i].scale.x=-2;
                }
                if(this.bee[i].position.x>8000){
                    this.bee[i].body.velocity.x=-300
                    this.bee[i].scale.x=2;
                }
            }

            if(this.heart<=-50){
                game.state.start('lost')
            }
        
        if(this.sonic.position.x>12600 && this.sonic.position.x<13000){
            this.tableEnd.body.gravity.y = 600
        }
        
        if(this.tableEnd.position.y>=730){
            this.tableEnd.body.gravity.y = 0
            this.tableEnd.body.velocity.y = 0
        }
    

        
	},
    damage: function(arg1, arg2){
        if(MainGame.heart!=0){
            MainGame.sonic.animations.play('damage')
        }
        if(MainGame.ringColl==0){
            MainGame.heart = MainGame.heart -1
        }
        if(MainGame.ringColl>0){
            MainGame.ringLos.play()
        }
        MainGame.sonic.body.velocity.y = -400;
        MainGame.sonic.body.gravity.y = 400;
        
        MainGame.ringColl = MainGame.ringColl - 20;
        
        if(MainGame.ringColl<0){
            MainGame.ringColl = 0
        }
        MainGame.ringsText.text = 'RINGS ' + MainGame.ringColl;
    },
	collect: function(arg1, arg2){
		MainGame.ringColl += 1;
        MainGame.ringsText.text = 'RINGS ' + MainGame.ringColl;
        MainGame.scoreText.text = 'SCORE ' + MainGame.ringColl*100;
        arg2.kill()
        MainGame.ringSound.play()
	},
    
    //RUNNING
	runR: function(){
        if(MainGame.sonic.body.touching.down && MainGame.hitPlatform){
            MainGame.sonic.animations.play('run')
        }else {
            MainGame.sonic.animations.play('jump1')
        }
        MainGame.sonic.body.velocity.x = 500;
        MainGame.sonic.scale.x=2;
        setTimeout(MainGame.RunR, 2000)
	},
	runL: function(){
        if(MainGame.sonic.body.touching.down && MainGame.hitPlatform){
            
            MainGame.sonic.animations.play('run')
            
        }else {
            MainGame.sonic.animations.play('jump1')
        }
        MainGame.sonic.body.velocity.x = -500;
        MainGame.sonic.scale.x=-2;
        setTimeout(MainGame.RunL, 2000)
	},
    
    //JUMPING
	jump: function(){
		if (MainGame.sonic.body.touching.down)
            {
            	MainGame.sonic.body.velocity.y = -500;
                MainGame.sonic.animations.play('jump1')
                setTimeout(MainGame.sonic.animations.play('jump2'), 2000)
                MainGame.jumpSound.play()
            }
		
	},
    
    //take a mode WAITING
	stop: function(){
		MainGame.sonic.body.velocity.x = 0;
		MainGame.sonic.animations.play('wait')
	},
    
    //FAST RUNNING
	RunR: function(){
        if(MainGame.sonic.body.touching.down && MainGame.hitPlatform){
            MainGame.sonic.animations.play('runF')
        }else {
            MainGame.sonic.animations.play('jump1')
        }
        MainGame.sonic.body.velocity.x = 700;
	},
	RunL: function(){
        if(MainGame.sonic.body.touching.down && MainGame.hitPlatform){
            MainGame.sonic.animations.play('runF')
        }else {
            MainGame.sonic.animations.play('jump1')
        }
        MainGame.sonic.body.velocity.x = -700;
	},
    
    //TIME CHANGINNG
    timeChan: function(){
        if(MainGame.timeI==60){
            MainGame.timeI=0
            MainGame.timeU+=1;
            MainGame.timeText.text = 'TIME ' + MainGame.timeU + ':' + MainGame.timeI;
        }else {
            MainGame.timeI+=1;
            MainGame.timeText.text = 'TIME ' + MainGame.timeU + ':' + MainGame.timeI;
        }
    }
}