var Start = {
    audio: null, 
	preload: function(){
		game.load.image('start', 'start.jpg')
        game.load.audio('audio', 'S1_A2.wav')
	},
	create: function(){
        this.audio = game.add.audio('audio', 1)
        this.audio.play()
        Menu.audio.pause()
		var bg = game.add.sprite(0, 0, 'start')
		bg.width = 1000
		bg.height = 600
		bg.inputEnabled=true;
		bg.events.onInputDown.add(this.start);
	},
	update: function(){

	},
	start: function(){
		game.state.start('game')
	}
}