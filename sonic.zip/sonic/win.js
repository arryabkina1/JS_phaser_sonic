var Win = {
	scoreText: null, 
	timeText: null, 
    ringsText: null,
    Text: null, 
    btn: null, 
    audio: null, 
	preload: function(){
		game.load.image('back', 'nextLevel.png')
        game.load.audio('clap', 'clap.mp3')
	},
	create: function(){
        this.audio = game.add.audio('clap', 1)
        this.audio.play()
        MainGame.audio.pause()  
		this.btn = game.add.sprite(380, 200, 'back')
        this.btn.scale.setTo(0.5)
		this.scoreText = game.add.text(100, 100, 'Congratulations!' , { fontSize: '50px', fill: '#6ecc10' });
		this.scoreText = game.add.text(100, 400, 'SCORE '+MainGame.ringColl*100, { fontSize: '40px', fill: '#ffe500' });
        this.timeText = game.add.text(100, 450, 'TIME '+MainGame.timeU+':'+MainGame.timeI, { fontSize: '40px', fill: '#ffe500' });
        this.ringsText = game.add.text(100, 500, 'RINGS '+MainGame.ringColl, { fontSize: '40px', fill: '#ffe500' });

		this.btn.inputEnabled=true;
        this.btn.events.onInputDown.add(this.menu);
	}, 
	update: function(){

	}, 
	menu: function(){
		game.state.start('cont')
	}
}